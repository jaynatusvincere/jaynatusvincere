/* path: jayell-universe/script.js */
/* Small enhancements: smooth scroll, active nav highlight, simple analytics */
document.addEventListener('DOMContentLoaded', () => {
  // smooth scroll for in-page links
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      const id = a.getAttribute('href');
      if (id && id !== '#') document.querySelector(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  // simple console greeting
  console.log('%cHi Jayell — Jayell Universe loaded.', 'color: #38bdf8; font-weight:700;');
});