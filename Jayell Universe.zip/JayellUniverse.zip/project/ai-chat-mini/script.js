/* path: projects/ai-chat-mini/script.js */
document.addEventListener('DOMContentLoaded', () => {
  const chat = document.getElementById('chat');
  const q = document.getElementById('q');
  const send = document.getElementById('send');

  function addMessage(text, who='bot') {
    const div = document.createElement('div');
    div.className = 'bubble ' + (who === 'user' ? 'user' : 'bot');
    div.textContent = text;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
  }

  send.addEventListener('click', () => {
    const val = q.value.trim();
    if (!val) return;
    addMessage(val, 'user');
    q.value = '';
    addMessage('Thinking...', 'bot');
    // mock "thinking"
    setTimeout(() => {
      chat.lastChild.textContent = "Mock answer: I can't call an LLM from here. Connect your backend to call real API.";
    }, 900);
  });

  q.addEventListener('keydown', (e) => { if (e.key === 'Enter') send.click(); });
});