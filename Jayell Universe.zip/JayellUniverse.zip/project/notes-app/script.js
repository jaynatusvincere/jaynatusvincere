/* path: projects/notes-app/script.js */
document.addEventListener('DOMContentLoaded', () => {
  const save = document.getElementById('save');
  const noteText = document.getElementById('noteText');
  const notesWrap = document.getElementById('notes');

  function load() {
    const data = JSON.parse(localStorage.getItem('jn_notes') || '[]');
    notesWrap.innerHTML = '';
    data.forEach((n, idx) => {
      const el = document.createElement('div'); el.className = 'note';
      el.innerHTML = `<div>${n}</div><div style="margin-top:8px;display:flex;gap:8px;justify-content:flex-end">
        <button data-idx="${idx}" class="del">Delete</button>
      </div>`;
      notesWrap.appendChild(el);
    });
    document.querySelectorAll('.del').forEach(b => b.addEventListener('click', (e) => {
      const idx = e.target.dataset.idx;
      const arr = JSON.parse(localStorage.getItem('jn_notes')||'[]');
      arr.splice(idx,1);
      localStorage.setItem('jn_notes', JSON.stringify(arr));
      load();
    }));
  }

  save.addEventListener('click', () => {
    const v = noteText.value.trim();
    if (!v) return alert('Write something first.');
    const arr = JSON.parse(localStorage.getItem('jn_notes')||'[]');
    arr.unshift(v);
    localStorage.setItem('jn_notes', JSON.stringify(arr));
    noteText.value = '';
    load();
  });

  load();
});