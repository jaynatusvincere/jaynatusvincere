/* path: projects/tiktok-downloader/script.js */
/* Visual-only: small animation and simulated download link */
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('url');
  const btn = document.getElementById('go');
  const status = document.getElementById('status');

  btn.addEventListener('click', (e) => {
    const url = input.value.trim();
    if (!url) {
      status.textContent = 'Please paste a TikTok URL.';
      return;
    }
    status.textContent = 'Processing... (visual demo)';
    btn.disabled = true;

    // simulate visual processing with particles and progress
    const body = document.body;
    const p = document.createElement('div');
    p.style.position = 'fixed';
    p.style.left = '50%';
    p.style.top = '30%';
    p.style.transform = 'translate(-50%,-50%)';
    p.style.color = '#bfefff';
    p.style.fontWeight = '700';
    p.style.fontFamily = 'Orbitron, sans-serif';
    p.textContent = 'Generating preview...';
    body.appendChild(p);

    setTimeout(() => {
      p.remove();
      status.innerHTML = 'Demo complete — <em>visual only</em>.';
      btn.disabled = false;
    }, 1400);
  });
});